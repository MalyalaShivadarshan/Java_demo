package Exercise;

import java.util.List;

public class Ex1 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		List<Integer>numbers=List.of(2,5,7,9,1,4);
		isOdd(numbers);
		

	}

	private static void isOdd(List<Integer> numbers)
	{
		numbers.stream().filter(number->number%2==1).sorted()
		.forEach(System.out::println);
		
	}

}
