package Exercise;

import java.util.List;

public class Ex2 {

	public static void main(String[] args) 
	{
		List<String>courses=List.of("Spring","Springboot","Docker","Aws");
		
		courses.stream()
		.filter(course->course.length()>=4)
		.map(course->course+" "+course.length())
		.forEach(System.out::println);
	}

	
}
