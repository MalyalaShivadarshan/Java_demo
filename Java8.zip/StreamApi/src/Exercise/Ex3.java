package Exercise;

import java.util.List;

public class Ex3 {

	public static void main(String[] args) {
		List<Integer>numbers=List.of(23,45,7,87,2,4,9,8,12);
		isdivisibleBy2(numbers);

	}

	private static void isdivisibleBy2(List<Integer> numbers) 

	{
		numbers.stream().filter(number -> number%2==0)//lambda expression
		.map(number -> number*number)//mapping numbers
		.forEach(System.out::println);//method reference
	}

}
