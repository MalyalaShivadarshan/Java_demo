package com.wipro.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FirstSBA {

	@RequestMapping("/welcome")
	public String display()
	{
		return "Welcome to frst application";
	}
}
