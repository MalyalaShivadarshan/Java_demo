package com.wipro.demo_springboot;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CourseController 
{
	
	@RequestMapping("/course")
	public List<course> retriveAllCourses(){
		return Arrays.asList (
				new course( 1,"Shiva","AWS"),
				new course(2,"chintu","SQL"));
				
				
				
				
				
	}
}
