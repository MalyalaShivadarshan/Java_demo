package com.wipro.demo_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
