package com.wipro.myFirstWeb.login;

import org.springframework.stereotype.Service;

@Service
public class AuthenticateService 
{
	public boolean authenticate(String username,String password)
	{
	Boolean isValidName=username.equalsIgnoreCase("wipro");
	Boolean isValidPassword=password.equalsIgnoreCase("shiva");
	
	return isValidName&&isValidPassword;
	}
}
